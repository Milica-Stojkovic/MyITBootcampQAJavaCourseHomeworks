package dz15122021;

//31. Napisati funkciju koja racuna proizvod 3 broja.
public class Pastebin31 {
    public static void main(String[] args) {
        System.out.println(proizvod(3, 5, 100));
    }

    public static int proizvod(int a, int b, int c) {
        return a * b * c;
    }
}



